
    <div id="footer_wrapper">



        <!-- START FOOTER -->

        <div id="social_box">


            <div id="footer_content">

                <div class="social_email_wrapper">
                    <div class="icons">
                    <ul class="social_list">

                        <li class="social_heading">Siguenos!</li>
                        <li class="">
                            <a href="https://twitter.com" target="_blank">
                                <div class="social_twitterIcon"></div>
                            </a>
                        </li>
                        <li class="">
                            <a href="https://www.facebook.com" target="_blank">
                                <div class="social_facebookIcon"></div>
                            </a>
                        </li>
                        <li class="">
                            <a href="https://www.instagram.com" target="_blank">
                                <div class="social_instagramIcon"></div>
                            </a>
                        </li>
                        <li class="">
                            <a href="https://plus.google.com" target="_blank">
                                <div class="social_gplusIcon"></div>
                            </a>
                        </li>
                    </ul>
                </div>
                    <div class="social_emailWrapper">
                        <form name="newsletter_signup_post" action="/newsletter_handler.cfm" data-err="Dirección electrónica incorrecta">
                            <input type="hidden" id="requestingPage" name="requestingPage" value="FTR"> <input type="hidden" id="thanksMsg" name="thanksMsg" value="¡Gracias por suscribirse!">
                            <label for="email">
								Regístrese para recibir nuestras ofertas actuales
							</label>
                            <div class="email_block">
                                <input type="text" id="email" name="email" value="Su e-mail" onfocus="this.value='';document.getElementById('email').className = '';" onblur="this.value=this.value==''?'Su e-mail':this.value;">
                                <button type="submit" class="email_btn" name="submitForm">
									Suscribirse
								</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div id="legal_box">
                    <div id="legal_content">
                        <div class="legal_list">
                            <ul>
                                <li><a href="<?= $helper->url('site','contact');?>">Política de privacidad</a></li>

                                <li><a href="<?= $helper->url('site','contact');?>">Condiciones generales</a></li>

                            </ul>
                            <ul>
                                
						<li>
												<img src="img/logo.png" alt="caralcarro" width="120" >
											</li>
                               

                            </ul>
                            <ul>

                               <li><a href="<?= $helper->url('site','contact');?>">Sobre nosotros</a></li>

                                <li><a href="<?= $helper->url('site','contact');?>">Por qué reservar con Auto Europe</a></li>
                            </ul>
                        </div>

                    </div>
                    <!-- /legal_content -->
                </div>
                <!-- /legal_box -->
            </div>
            <!-- /footer_content -->
        </div>
        <!-- /social_box or footer_box, depending on condition -->




        <div id="cred_wrapper">
            <div id="cred_box">
                <p class="cred_icons">
                </p>
                <ul class="cred_list">

                    <li><a href="http://www.spain.info" title="Spain Info" rel="nofollow" target="_blank"><img src="img/spinfo-seal.jpg" alt="Spain Info" border="0"></a></li>


                    <li class="trustWave_V3">
                        <a href="https://sealserver.trustkeeper.net" target="hATW"><img src="http://www.autoeurope.es/img/ui/trustwave-seal.png" alt="Trusted Commerce" width="101" height="51"></a>
                    </li>
                    <li style="display:inline-block;width:130px">
                        <span style="width:130px;">
						
						<!-- GLOBALSIGN SEAL -->
						<table width="125" border="0" cellspacing="0" cellpadding="0" title="CLICK TO VERIFY: This site uses a GlobalSign SSL Certificate to secure your personal information."><tbody><tr><td><script src="//ssif1.globalsign.com/"></script><span> <a id="aa" href="javascript:ss_open_sub()"><img name="ss_imgTag" border="0" src="//ssif1.globalsign.com/SiteSeal/siteSeal/siteSeal/siteSealImage.do?p1=www.autoeurope.es&amp;p2=SZ100-40&amp;p3=image&amp;p4=en&amp;p5=V0023&amp;p6=S001&amp;p7=http&amp;deterDn=" alt="Por favor haga clic para ver el perfil." oncontextmenu="return false;" galleryimg="no" style="width:100px"></a></span>
                        <span
                            id="ss_siteSeal_fin_SZ100-40_image_en_V0023_S001"></span>
                            <script type="text/javascript" src="//seal.globalsign.com/SiteSeal/gmogs_image_100-40_en_dblue.js" async="" defer=""></script>
                            </td>
                            </tr>
                            </tbody>
                            </table>

                            </span>
                    </li>
                </ul>
            </div>
        </div>

    </div>
