<?php
define("CONTROLADOR_DEFECTO", "Site");
define("ACCION_DEFECTO", "index");
//Más constantes de configuración
?>
