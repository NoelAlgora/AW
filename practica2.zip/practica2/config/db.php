<?php
return array(
    "host"      =>"localhost",
    "user"      =>"root",
    "pass"      =>"",
    "database"  =>"caralcarro",
);
?>